=========================================
FilterVST3 - Plugin de Audio Cross-Platform
=========================================

Este plugin VST3 funciona en Windows, macOS y Linux.

ARCHIVOS INCLUIDOS:
- CMakeLists.txt: Configuración de compilación
- FilterVST3.h/.cpp: Código fuente del plugin
- build.bat: Script de compilación para Windows
- build.sh: Script de compilación para macOS/Linux
- resource/: Archivos de recursos (Windows)
- INSTALL_MACOS.txt: Instrucciones específicas para Mac

INSTRUCCIONES RÁPIDAS:

WINDOWS:
1. Instalar Visual Studio 2022 y VST3 SDK
2. Ejecutar: build.bat

macOS:
1. Instalar Xcode y VST3 SDK
2. Ejecutar: chmod +x build.sh && ./build.sh

LINUX:
1. Instalar GCC/Clang y VST3 SDK
2. Ejecutar: chmod +x build.sh && ./build.sh

CARACTERÍSTICAS:
- Filtro Low-Pass y High-Pass
- Procesamiento estéreo
- Compatible con todos los DAWs VST3
- Código fuente cross-platform

SOPORTE:
Consulta los archivos INSTALL_*.txt para instrucciones detalladas.

IMPORTANTE:
Este paquete contiene el código fuente. Cada usuario debe compilar
el plugin en su plataforma específica. No se puede usar el binario
compilado en una plataforma diferente. 